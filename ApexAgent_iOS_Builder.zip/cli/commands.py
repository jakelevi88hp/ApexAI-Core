@cli.command("ios:build", help="Trigger autonomous iOS build with ApexAI")
def build_ios_command():
    from modules.ios_autobuild import execute_ios_build
    execute_ios_build()
