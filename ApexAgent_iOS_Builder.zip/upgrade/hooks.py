UPGRADE_HOOKS = {
    "ios_builder": {
        "description": "Upgrade iOS build module (Fastlane + CLI)",
        "upgrade_cmd": "pip install --upgrade fastlane-cli && git pull && python regenerate_fastfile.py"
    }
}
