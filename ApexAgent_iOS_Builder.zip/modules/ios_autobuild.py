import subprocess, os, time, json
from apexcore.ml import learn_from_logs, suggest_fixes
from apexcore.autocode import regenerate_fastfile
from apexcore.utils import log, archive_build_output, report_status

FASTLANE_LANES = ["apex_debug", "apex_release", "apex_test", "build", "deploy"]

def run_lane(lane, use_bundle):
    cmd = f"bundle exec fastlane {lane}" if use_bundle else f"fastlane {lane}"
    log(f"🚀 Running lane: {lane}")
    result = subprocess.run(cmd, shell=True, capture_output=True, text=True)
    log_path = f"logs/ios_{lane}_{int(time.time())}.log"
    with open(log_path, "w") as f:
        f.write(result.stdout + "\n" + result.stderr)
    archive_build_output("build", f"artifacts/{lane}")
    return log_path, result.returncode

def execute_ios_build():
    os.chdir("C:/Path/To/Your/iOSApp")
    use_bundle = os.path.exists("Gemfile")

    if use_bundle:
        subprocess.run("gem install bundler", shell=True)
        subprocess.run("bundle install", shell=True)
    else:
        subprocess.run("gem install fastlane", shell=True)

    for lane in FASTLANE_LANES:
        log_path, code = run_lane(lane, use_bundle)
        if code != 0:
            report_status(f"❌ Lane failed: {lane}, analyzing log...")
            fix = suggest_fixes(log_path)
            if fix:
                log(f"🧠 AutoCode Suggestion: {fix}")
                regenerate_fastfile(fix)
                break

    learn_from_logs("logs/")
    report_status("✅ iOS Autobuild Complete.")

if __name__ == "__main__":
    execute_ios_build()
